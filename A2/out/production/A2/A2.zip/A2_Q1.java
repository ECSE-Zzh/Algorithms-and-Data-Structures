import java.util.*;

public class A2_Q1{
	
	public static int game_recursion(int[][] board) {
		int score = 0;
		helper(board, 0, 0, score);
		return score;
	}


	public static void helper(int[][] board, int row, int col, int score){
		//base case
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				if (board[i][j] > 0 && board[i][j + 1] > 0) {
					break;
				} else if (board[i][j] > 0 && board[i + 1][j] > 0) {
					break;
				} else if (board[i][j] > 0 && board[i + 1][j + 1] > 0) {
					break;
				} else {
					return;
				}
			}
		}

		//检查是否可移动 下
		int preDownRowPlus1 = board[row+1][col];
		int preDownRow = board[row][col];
		int preDownRowPlus2 = board[row+2][col];
		if (board[row+2][col] == 0 && board[row+1][col] > 0 &&board[row][col] > 0){
			board[row+2][col] = board[row][col];
			int scoreDown = board[row][col] * board[row+1][col];
			board[row+1][col] = 0;
			board[row][col] = 0;
		} else {
			//不可移动的话，检查下一行
			helper(board, row+1, col, score);
		}

		//退回挪动前的位置
		board[row+1][col] = preDownRowPlus1;
		board[row][col] = preDownRow;
		board[row+2][col] = preDownRowPlus2;
		//检查其他路径 右
		int preRightColPlus1 = board[row][col+1];
		int preRightCol = board[row][col];
		int preRightColPlus2 = board[row][col+2];

		if (board[row][col+2] == 0 && board[row][col+1] > 0 && board[row][col] > 0){
			board[row][col+2] = board[row][col];
			int scoreRight = board[row][col] * board[row][col+1];
			board[row][col+1] = 0;
			board[row][col] = 0;
		} else {
			//不可移动的话，检查下一列
			helper(board, row, col+1, score);
		}

		//退回挪动前位置
		board[row][col+1] = preRightColPlus1;
		board[row][col] = preRightCol;
		board[row][col+2] = preRightColPlus2;
		//检查其他路径 斜下
		int preDiagDownPlus1 = board[row+1][col+1];
		int preDiagDown = board[row][col];
		int preDiagDownPlus2 = board[row+2][col+2];

		if (board[row+2][col+2] == 0 && board[row+1][col+1] > 0 && board[row][col] > 0){
			board[row+2][col+2] = board[row][col];
			int scoreDiagDown = board[row][col] * board[row+1][col+1];
			board[row+1][col+1] = 0;
			board[row][col] = 0;
		} else {
			//不可移动的话，检查下一个
			helper(board, row+1, col+1, score);
		}
	}
}
