import java.util.*;

public class A2_Q4 {
	
	public static double swaps(int[] passengers) {

		return -1;
	}
	
}
