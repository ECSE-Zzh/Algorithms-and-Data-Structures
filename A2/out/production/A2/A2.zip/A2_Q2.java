import java.util.*;

public class A2_Q2 {

	public static int change(int[] denominations) {
		return -1;
	}

}
